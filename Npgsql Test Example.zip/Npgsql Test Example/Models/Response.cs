﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyBackEnd.Models
{
    public class Response
    {
        public bool success { get; set; }
    }
}
